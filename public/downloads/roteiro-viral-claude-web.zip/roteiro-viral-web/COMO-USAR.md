# Como usar a skill "roteiro-viral" no Claude Web (claude.ai)

Esta versão funciona sem instalar nada, direto no navegador. Você tem duas formas
de usar o arquivo `roteiro-viral-instrucoes.md` deste .zip.

## Opção 1: como Project (recomendado, configura uma vez só)

1. Entre no claude.ai e crie um novo **Project**.
2. Abra as **instruções do Project** (custom instructions).
3. Copie TODO o conteúdo do arquivo `roteiro-viral-instrucoes.md` e cole ali.
4. Salve. Pronto: toda conversa dentro desse Project já vira roteiro viral.

A partir daí, é só abrir uma conversa no Project e mandar o tema:

> cria um roteiro sobre a nova skill do Claude que edita vídeo

Ou anexar prints de uma ferramenta e pedir o roteiro.

## Opção 2: colar direto no chat (uso avulso)

Se não quiser criar um Project, cole o conteúdo de `roteiro-viral-instrucoes.md`
no começo de uma conversa nova e, na sequência, escreva o seu tema. Funciona
também no ChatGPT e em outras IAs.

## Dica

Gere 2 ou 3 versões do mesmo tema e escolha o hook mais forte. O gerador já te
entrega um gancho alternativo a cada roteiro. Varie a palavra-gatilho pra não
repetir sempre a mesma.

Feito por @rafa.grandi.
