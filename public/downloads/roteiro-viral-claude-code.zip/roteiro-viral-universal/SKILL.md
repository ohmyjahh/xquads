---
name: roteiro-viral-universal
description: >-
  Cria roteiros de Reels virais para QUALQUER nicho no padrão @rafa.grandi (framework RG-1).
  Use quando o usuário quer gerar um roteiro de Reel/short passando apenas um TEMA (ex: "app que
  monta treino sozinho", "erro que quebra quem investe em renda fixa", "receita de pão sem forno")
  ou anexando PRINTS de uma novidade/produto/tela. Gera a narração pronta seguindo hook + passo a
  passo + prova + CTA "comenta que mando no Direct". Framework derivado da engenharia reversa de 55
  Reels de alto desempenho (+40 mil views cada). Serve para fitness, finanças, beleza, culinária,
  negócios, pet, viagem, educação, tecnologia e qualquer outro nicho.
---

# Roteiro Viral Universal (Padrão RG-1)

Gera a **narração falada** de um Reel viral sobre **qualquer assunto**, a partir de um tema ou de
prints, replicando o padrão RG-1 (estrutura de 55 Reels de alto desempenho, todos >40 mil views).

O framework é agnóstico de nicho: a mesma estrutura que faz um Reel de IA viralizar faz um Reel de
fitness, de finanças ou de receita viralizar. O que muda é só o assunto e as referências.

## Quando usar
- Usuário diz: "cria um roteiro sobre X", "roteiro viral de X", "faz um Reel sobre isso".
- Usuário anexa prints de uma novidade/produto/tela e pede um roteiro.
- Usuário quer 2–3 variações de hook para o mesmo tema.

## Antes de gerar: descubra o nicho
Se o nicho não estiver óbvio no tema, identifique-o em 1 linha (ex: fitness, finanças pessoais,
beleza, culinária, marketing, pet, viagem, maternidade, tecnologia). O nicho define:
- **A autoridade** que ancora a novidade (uma marca, um especialista, um estudo, um número oficial).
- **O vocabulário** e o tom (o público de finanças fala diferente do público de beleza).
- **O entregável do CTA** (o prompt, a planilha, a receita, a lista, o treino, o passo a passo).
Se o tema vier muito vago, faça no máximo 1 pergunta de esclarecimento; caso contrário, gere direto.

## Entrada esperada
- **Tema** (texto curto): ex. "app que monta treino sozinho", "3 erros de quem começa a investir".
- **OU prints**: analise as imagens (nome do produto, novidade, telas de passo a passo) e use como base factual.

## Processo (siga sempre)

1. **Escolha o ângulo do HOOK** — o mais forte entre os 9 tipos (priorize os que mais viralizam).
   Os templates abaixo valem para qualquer nicho; troque o conteúdo entre chaves pelo seu assunto:
   - **Demissão/Substituição**: "Pode parar de {tarefa cara/trabalhosa}, porque {solução} vai fazer isso por você."
   - **Notícia-bomba**: "{Marca/pessoa/estudo} acabou de {lançar/provar/mudar} {coisa grande do nicho}."
   - **Valor chocante**: "{resultado em R$/kg/tempo/seguidores} usando só {método/produto}."
   - **Pergunta-curiosidade**: "O que acontece quando você {ação inesperada do nicho}? Eu testei e {resultado}."
   - **Lista numerada**: "Esses são os {N} {erros/truques/produtos/passos} que {promessa}."
   - **Prova/resultado**: "Eu {resultado concreto} em {tempo} e vou te ensinar exatamente como."
   - **Contrário/polêmico**: afirmação que contraria o senso comum do nicho.
   - **Tutorial direto**: "Eu vou te ensinar como {benefício} em menos de 1 minuto."
   - **Promessa de benefício**: "É assim que você consegue {benefício que parecia impossível}."

2. **Escreva os 6 blocos NA ORDEM**, como texto corrido de narração (sem títulos, sem marcação de cena):
   1. **HOOK** — 1 frase de choque (~8–20 palavras).
   2. **PROMESSA + PONTE** — reafirma o benefício + razão-de-crer (é novo / é de graça / uma autoridade fez / você testou) + "eu vou te ensinar" / "em menos de 1 minuto".
   3. **PASSO A PASSO** — 4 a 8 micro-passos com conectores: *"Primeiro… Depois… Agora vem o segredo (pulo do gato)… Por último…"*. Ações curtas e imperativas. Inclua UM "segredo" no meio.
   4. **PROVA/PAYOFF** — "olha o resultado / olha o nível / em poucos minutos / em poucas semanas eu {resultado concreto}".
   5. **CTA** — "Se você quer que eu te mande **[ENTREGÁVEL específico]**, comenta aqui embaixo **[PALAVRA-GATILHO de 1 palavra ligada ao tema]** que eu te mando pelo Direct."
   6. **ASSINATURA** — termine com a sua assinatura de marca (padrão: **"Tamo junto e let's go!"**; troque pelo seu bordão se tiver um).

3. **Ao final**, entregue em linhas separadas:
   - `NICHO: [x]`
   - `PALAVRA-GATILHO: [x]`
   - `GANCHO ALTERNATIVO: [reescreva o hook em outro dos 9 ângulos]`
   - `CONTAGEM: [nº de palavras] palavras / [nº] caracteres`

## Regras obrigatórias (não quebrar)
- **Tamanho**: 170–240 palavras (900–1.400 caracteres). Fala de 45–90 segundos. Se passar, corte.
- **Voz**: 2ª pessoa, oral e informal (mistura "tu/você", "teu/seu"). Frases curtas e imperativas. Nada corporativo, nada de emoji no roteiro. Ajuste o vocabulário ao nicho, mantendo o tom oral.
- **Credibilidade**: use pelo menos 1 número concreto ("3x mais", "em 30 dias", "mais de 10 mil pessoas") e, quando fizer sentido, 1 nome de autoridade do nicho (uma marca conhecida, um especialista, um estudo, um órgão oficial).
- **Não invente fatos verificáveis falsos**. Se não souber o dado exato, use faixa plausível ("mais de", "quase", "já passa de").
- **Gatilhos**: encaixe urgência/facilidade/gratuidade quando couber ("acabou de sair", "totalmente gratuito", "é muito fácil").
- **CTA sempre** com ENTREGÁVEL + PALAVRA-GATILHO. Varie a palavra-gatilho a cada roteiro.
- **Adapte a autoridade ao nicho**: em vez de forçar nomes de tecnologia, use a referência que faz sentido para o assunto (um nutricionista, um economista, um chef, a Anvisa, um estudo publicado etc.).

## Padrão de saída
Entregue primeiro o **roteiro limpo** (pronto pra gravar/decorar), depois o bloco de metadados
(NICHO / PALAVRA-GATILHO / GANCHO ALTERNATIVO / CONTAGEM). Se o usuário pedir variações, gere 2–3
hooks diferentes para o mesmo corpo.

## Referência completa
O framework detalhado (diagnóstico dos padrões, tabelas de frequência, os 9 tipos de hook, checklist
de viralização e exemplos de vários nichos) está em `reference.md` nesta mesma pasta.

## Checklist rápido antes de entregar
- [ ] Hook cabe em 3s e provoca choque/curiosidade?
- [ ] Tem número concreto e/ou autoridade do nicho nos primeiros 8s?
- [ ] Passo a passo com ≤8 micro-passos e 1 "segredo"?
- [ ] Tem momento "olha o resultado"?
- [ ] CTA pede pra comentar 1 palavra-gatilho ligada ao tema?
- [ ] Fechou com a assinatura de marca?
- [ ] 170–240 palavras / 900–1.400 caracteres?
- [ ] O vocabulário e a autoridade batem com o nicho do tema?
