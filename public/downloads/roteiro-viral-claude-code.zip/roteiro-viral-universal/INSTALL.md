# Como instalar a skill "roteiro-viral-universal" no Claude Code

Esta skill faz o Claude Code gerar roteiros de Reels virais no padrão @rafa.grandi
(framework RG-1), para QUALQUER nicho: fitness, finanças, beleza, culinária,
negócios, pet, viagem, educação, tecnologia e o que mais você trabalhar. Basta
passar um tema ou anexar prints.

## Instalação (1 minuto)

1. Descompacte este .zip. Você vai ter uma pasta `roteiro-viral-universal` com os
   arquivos `SKILL.md` e `reference.md`.

2. Mova a pasta `roteiro-viral-universal` inteira para o diretório de skills do
   Claude Code:

   - **Mac / Linux:** `~/.claude/skills/roteiro-viral-universal/`
   - **Windows:** `C:\Users\SEU_USUARIO\.claude\skills\roteiro-viral-universal\`

   No fim, o caminho deve ficar assim:
   `~/.claude/skills/roteiro-viral-universal/SKILL.md`

3. Abra (ou reinicie) o Claude Code. A skill é detectada automaticamente.

## Como usar

Peça um roteiro passando só o tema, seja qual for o nicho:

> cria um roteiro viral sobre um treino de 15 minutos em casa

> cria um roteiro sobre 3 erros de quem começa a investir

Ou anexe prints de um produto/novidade e peça o roteiro. O Claude devolve a
narração pronta pra gravar, no padrão hook + passo a passo + prova + CTA, mais o
nicho identificado, a palavra-gatilho e um gancho alternativo.

## O que tem dentro

- `SKILL.md` — as regras que o Claude segue pra gerar o roteiro em qualquer nicho.
- `reference.md` — o framework completo: diagnóstico dos padrões, os 9 tipos de
  hook com exemplos de vários nichos, checklist de viralização e exemplos prontos.

Feito por @rafa.grandi.
