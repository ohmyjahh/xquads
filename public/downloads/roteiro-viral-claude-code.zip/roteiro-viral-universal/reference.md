# FRAMEWORK DE ROTEIROS VIRAIS — Padrão @rafa.grandi (Universal, qualquer nicho)

> Framework derivado da **engenharia reversa de 55 Reels de alto desempenho (>40 mil views cada**, soma > 15 milhões de views, pico de 1,4 milhão). A amostra original era de conteúdo de IA, mas o que foi extraído é a **estrutura**, e estrutura não tem nicho: o mesmo esqueleto que faz um Reel de IA estourar faz estourar um de fitness, finanças, beleza ou culinária. Este documento tem 4 partes: **(1) Diagnóstico** dos padrões, **(2) O Framework** acionável, **(3) O Gerador** (prompt pronto pra colar tema/prints e sair roteiro) e **(4) Exemplos** de nichos variados.

---

# PARTE 1 — DIAGNÓSTICO (o que os dados provam)

## 1.1 Números-âncora (respeite estes limites, valem para qualquer nicho)
| Métrica | Valor | Regra prática |
|---|---|---|
| Caracteres | média **1.154** / mediana **1.129** (faixa 600–2.183) | Mire **900–1.400 caracteres** |
| Palavras | média **206** / mediana **202** | Mire **170–240 palavras** |
| Duração falada | média **~82s** (1,4 min) | Reel de **45s–90s** |
| Estrutura | 6 blocos fixos (abaixo) | Nunca pule o Hook nem o CTA |

## 1.2 Fórmulas de engajamento mais frequentes (nº de ocorrências nos 55)
Estas fórmulas aparecem independentemente do assunto. Adapte a linguagem, mantenha a mecânica.
- **"te mando pelo Direct"** → 83x (é o motor do engajamento)
- **"let's go!" / bordão de fechamento** → 52x
- **"comenta aqui embaixo [palavra]"** → 42x
- **"tamo/estamos/temos junto"** → 39x
- **"a partir de agora/hoje"** → 24x
- **"acabou de [lançar/sair/provar]"** → 20x
- **"eu vou te ensinar"** → 16x
- **"me segue aqui embaixo"** → 14x
- **"gratuito/grátis"** → 14x
- **"em menos de X segundos/1 minuto"** → 8x
- **"pode parar de [tarefa cara]"** → 6x

## 1.3 Os 9 tipos de HOOK (primeiros 3 segundos)
Todo Reel abre com UM destes ângulos. Os exemplos abaixo mostram o mesmo tipo aplicado a nichos
diferentes, pra provar que o molde é universal. Ordenados por potência:

1. **DEMISSÃO/SUBSTITUIÇÃO** — "Pode parar de {tarefa cara/trabalhosa}, porque {solução} vai fazer por você."
   - *Finanças:* "Pode cancelar o teu consultor, porque essa planilha faz o teu controle sozinha."
   - *Fitness:* "Pode largar a academia lotada, porque esse treino de 15 minutos entrega mais."
2. **NOTÍCIA-BOMBA / novidade** — "{Marca/pessoa/estudo} acabou de {lançar/provar/mudar} {coisa grande}."
   - *Beleza:* "A Anvisa acabou de proibir esse ingrediente que tá em quase todo shampoo."
   - *Culinária:* "Descobriram um jeito de fazer pão sem forno que tá viralizando."
3. **TUTORIAL DIRETO** — "Eu vou te ensinar como {benefício}…", "Como {tarefa do nicho} do jeito certo."
4. **PERGUNTA/CURIOSIDADE** — "O que acontece quando você {ação inesperada}? Eu testei e {resultado}."
5. **LISTA NUMERADA** — "Esses são os {N} {erros/truques/produtos} que {promessa}."
   - *Pet:* "3 comidas que você dá pro seu cachorro achando que faz bem e faz mal."
6. **RESULTADO / PROVA SOCIAL** — "Eu {resultado concreto} em {tempo} e vou te mostrar como."
   - *Finanças:* "Juntei meus primeiros 10 mil em 8 meses ganhando salário mínimo, e vou te ensinar."
7. **PROMESSA DE BENEFÍCIO** — "É assim que você consegue {benefício que parecia impossível}."
8. **CONTRÁRIO/POLÊMICO** — afirmação que contraria o senso comum do nicho.
   - *Fitness:* "Fazer abdominal todo dia não te dá barriga chapada, e eu vou provar."
9. **VALOR CHOCANTE** — "{valor em R$/kg/tempo/seguidores} usando só {método/produto}."

## 1.4 Estrutura universal (6 BLOCOS)
```
[1] HOOK          (0–3s)   → 1 frase de choque. Um dos 9 tipos acima.
[2] PROMESSA+PONTE (3–8s)  → o que vai ensinar + porque agora (autoridade/novidade/prova) + "eu vou te ensinar"
[3] PASSO A PASSO (8–55s)  → "Primeiro… depois… agora… por último". Instrução prática, curta, imperativa.
[4] PROVA/PAYOFF  (~5s)    → "e esse é o resultado", "olha o nível", "em poucas semanas eu…"
[5] CTA           (~8s)    → "Se você quer [ENTREGÁVEL], comenta [PALAVRA] que eu te mando pelo Direct"
[6] ASSINATURA    (~2s)    → seu bordão de marca (padrão: "Tamo junto e let's go!")
```

## 1.5 Regras de estilo de escrita (voz da marca)
- **2ª pessoa, oral e informal** — mistura "tu/você", "teu/seu". Fala como amigo, não como professor.
- **Frases curtas e imperativas** no passo a passo: "Você vai fazer isso.", "Anota esse número.", "Testa hoje."
- **Conectores de fluxo** obrigatórios: *Primeiro… / Depois… / Agora vem o segredo (ou o pulo do gato)… / Por último… / E o melhor…*
- **Números concretos e específicos** = credibilidade: adapte ao nicho ("3x mais", "em 30 dias", "menos de R$50", "10 mil pessoas", "2 kg em um mês").
- **Nomes de autoridade** ancoram a novidade — escolha o que faz sentido no nicho: uma marca conhecida, um especialista (nutricionista, economista, dermatologista, chef), um órgão oficial (Anvisa, Banco Central), um estudo publicado.
- **Urgência + escassez + gratuidade**: "acabou de sair", "por tempo limitado", "totalmente gratuito", "só pra quem pedir".
- **Facilidade**: "é muito fácil e simples", "em menos de 1 minuto".
- **Demonstração em tempo real**: "olha isso", "olha o nível", "esse é o resultado".

## 1.6 Anatomia do CTA (o motor do algoritmo)
**Fórmula-padrão (usada em ~42 dos 55):**
> "[E] se você quer que eu te mande **[ENTREGÁVEL ESPECÍFICO]**, comenta aqui embaixo **[PALAVRA-GATILHO]** que eu te mando pelo Direct. **[SEU BORDÃO]**"

- **ENTREGÁVEL** = a recompensa concreta do nicho: a planilha, a receita, a lista de produtos, o treino, o passo a passo, o modelo, o prompt, a aula.
- **PALAVRA-GATILHO** = 1 palavra curta ligada ao tema, que a pessoa comenta pra receber no Direct. Ex.: `treino`, `planilha`, `receita`, `pele`, `investir`, `pet`, `dieta`, `viagem`, `orçamento`.
- **CTA alternativo** (quando não há entregável de Direct): "Se você quer mais conteúdo sobre {nicho}, já me segue aqui embaixo."

---

# PARTE 2 — O FRAMEWORK (a fórmula para escrever)

## FÓRMULA VIRAL RG-1 (preencha os blocos)

**BLOCO 1 — HOOK** *(1 frase, ~8–20 palavras)*
Escolha 1 dos 9 tipos. Priorize DEMISSÃO, NOTÍCIA-BOMBA ou VALOR CHOCANTE (os de maior potência).
> Templates (troque as chaves pelo seu nicho):
> - "Pode parar de {tarefa cara/trabalhosa}, porque {solução} vai {fazer isso} por você."
> - "{Marca/especialista/estudo} acabou de {lançar/provar/mudar} {coisa grande}."
> - "A partir de agora você consegue {benefício impossível antes} usando {método/produto}."
> - "O que acontece quando você {ação inesperada}? Eu testei e {resultado}."
> - "Esses são os {N} {erros/truques/produtos} {secretos/gratuitos} que {promessa}."
> - "{Valor chocante em R$/kg/tempo/seguidores} usando só {método}. E eu vou te ensinar como."

**BLOCO 2 — PROMESSA + PONTE** *(1–2 frases)*
Reafirma o benefício, adiciona a razão-de-crer (é novo / é de graça / uma autoridade fez / você testou) e promete o passo a passo.
> "…e eu vou te ensinar a fazer isso agora, em menos de 1 minuto." / "É muito fácil e eu vou te mostrar."

**BLOCO 3 — PASSO A PASSO** *(o corpo, 4–8 micro-passos)*
Sequência prática com os conectores. Cada passo = 1 ação curta e imperativa. Insira **1 "segredo/pulo do gato"** no meio (o passo que ninguém conhece).
> "Primeiro, você vai {ação}. Depois, {ação}. **Agora vem o segredo:** {ação diferenciada}. Por último, {ação}."

**BLOCO 4 — PROVA / PAYOFF** *(1–2 frases)*
Mostra o resultado pronto e impressiona.
> "Só com isso, esse é o resultado. Olha o nível." / "Em poucas semanas eu {resultado concreto}."

**BLOCO 5 — CTA** *(1–2 frases)*
Use a fórmula do item 1.6. Sempre com ENTREGÁVEL + PALAVRA-GATILHO.

**BLOCO 6 — ASSINATURA**
> Seu bordão de marca. Padrão: "Tamo junto e let's go!"

## Checklist de viralização (antes de gravar)
- [ ] O Hook cabe em 3 segundos e provoca choque/curiosidade?
- [ ] Tem número concreto ou autoridade do nicho nos primeiros 8s?
- [ ] O passo a passo tem no máximo ~8 micro-passos e um "segredo"?
- [ ] Tem um momento "olha o resultado" (payoff)?
- [ ] O CTA pede pra comentar UMA palavra-gatilho ligada ao tema?
- [ ] Fechou com o bordão de marca?
- [ ] Total entre 900–1.400 caracteres (~45–90s)?
- [ ] Linguagem oral, frases curtas, "tu/você" informal?
- [ ] O vocabulário e a autoridade batem com o nicho?

---

# PARTE 3 — O GERADOR (cole isto numa IA + seu tema)

> Copie o bloco abaixo inteiro. Substitua `{{TEMA}}` pelo assunto (ou descreva os prints que vai anexar). A IA devolve o roteiro pronto no padrão, seja qual for o nicho.

```
Você é um roteirista de Reels virais treinado no estilo do perfil @rafa.grandi (framework RG-1).
Sua tarefa é escrever UM roteiro de Reel (só a narração/fala, sem marcações de cena) sobre o tema
abaixo, seguindo EXATAMENTE o framework RG-1. O framework serve para qualquer nicho.

TEMA / PRINTS: {{TEMA}}

PASSO 0 — Identifique o nicho do tema em 1 linha (ex: fitness, finanças, beleza, culinária, pet,
negócios). Isso define a autoridade, o vocabulário e o entregável do CTA.

REGRAS OBRIGATÓRIAS:
1. Tamanho: 170–240 palavras (900–1.400 caracteres). Fala de 45–90 segundos.
2. Voz: 2ª pessoa, oral, informal (mistura "tu/você"), frases curtas e imperativas. Nada corporativo.
   Ajuste o vocabulário ao nicho.
3. Siga os 6 blocos NA ORDEM, sem títulos, como texto corrido de narração:
   - HOOK (1 frase de choque — escolha o ângulo mais forte entre: Demissão/Substituição,
     Notícia-bomba, Valor chocante, Pergunta-curiosidade, Lista numerada, Prova/resultado,
     Contrário/polêmico).
   - PROMESSA + PONTE: reafirme o benefício + razão-de-crer (é novo / de graça / autoridade fez /
     você testou) + "eu vou te ensinar" / "em menos de 1 minuto".
   - PASSO A PASSO: 4 a 8 micro-passos com os conectores "Primeiro… Depois… Agora vem o segredo…
     Por último…". Inclua UM "pulo do gato" no meio.
   - PROVA/PAYOFF: "olha o resultado / olha o nível / em pouco tempo eu…".
   - CTA: "Se você quer que eu te mande [ENTREGÁVEL específico ligado ao tema], comenta aqui
     embaixo [PALAVRA-GATILHO de 1 palavra ligada ao tema] que eu te mando pelo Direct."
   - ASSINATURA: termine com "Tamo junto e let's go!" (ou o bordão que o usuário indicar).
4. Use pelo menos 1 número concreto e, se fizer sentido, 1 nome de autoridade DO NICHO (uma marca,
   um especialista, um órgão oficial, um estudo). Não invente dados falsos verificáveis; se não
   souber o número exato, use faixas plausíveis ("mais de", "quase").
5. Gatilhos de urgência/facilidade/gratuidade quando couber ("acabou de sair", "totalmente
   gratuito", "é muito fácil").
6. Entregue TAMBÉM, ao final, em linhas separadas:
   - "NICHO: [x]"
   - "PALAVRA-GATILHO: [x]"
   - "GANCHO ALTERNATIVO: [reescreva o hook em outro dos 9 ângulos]"

Escreva o roteiro agora.
```

### Como usar no dia a dia
1. **Só tema:** troque `{{TEMA}}` por ex. *"app que monta treino sozinho"* → sai o roteiro.
2. **Com prints:** anexe os prints e ponha em `{{TEMA}}`: *"baseie-se nos prints anexados desta novidade/produto"*.
3. Gere 2–3 versões, escolha o hook mais forte (o gerador já te dá um alternativo).
4. Ajuste a PALAVRA-GATILHO pra não repetir sempre a mesma.

---

# PARTE 4 — EXEMPLOS gerados do zero (nichos variados, prova de que funciona)

### Exemplo A — Nicho: Finanças pessoais · Tema: "planilha que organiza o salário sozinha"
> Pode cancelar aquela consultoria financeira cara, porque essa planilha organiza o teu salário inteiro sozinha, e é de graça. Eu vou te mostrar como colocar as tuas finanças no controle em menos de 2 minutos. Primeiro, você vai baixar a planilha e abrir no seu celular mesmo. Depois, joga o valor do teu salário lá em cima. Agora vem o segredo: ative a regra 50-30-20 que já vem embutida, ela separa sozinha o que é pra conta, o que é pra prazer e o que é pra guardar. Por último, é só olhar o gráfico que ela monta e ver pra onde teu dinheiro tá indo de verdade. E olha o nível: em segundos ela me mostrou que eu gastava quase 800 reais por mês numa categoria que eu nem percebia. Um contador trabalhando pra você, sem pagar nada. Se você quer que eu te mande essa planilha pronta, comenta aqui embaixo PLANILHA que eu te mando pelo Direct. Tamo junto e let's go!
>
> **NICHO:** Finanças pessoais · **PALAVRA-GATILHO:** PLANILHA · **GANCHO ALTERNATIVO (Valor chocante):** "Achei quase 800 reais por mês escondidos no meu salário com uma planilha de graça."

### Exemplo B — Nicho: Fitness · Tema: "treino de 15 minutos em casa sem equipamento"
> Você não precisa de academia nem de nenhum equipamento pra secar, e eu vou provar. Esse treino de 15 minutos em casa queima mais que meia hora de esteira, e a ciência já mostrou isso. Primeiro, você vai fazer 40 segundos de agachamento no seu ritmo. Depois, 40 segundos de flexão, pode ser com o joelho no chão. Agora vem o pulo do gato: no lugar de descansar parado, você mantém o corpo em movimento leve entre um exercício e outro, é isso que segura o teu batimento lá em cima e faz a queima continuar. Por último, fecha com 40 segundos de prancha. Repete esse circuito 3 vezes e acabou. Eu fiz isso por 4 semanas, 4 vezes por semana, e a diferença no espelho foi absurda, sem sair de casa. Se você quer que eu te mande esse treino completo com os dias montados, comenta aqui embaixo TREINO que eu te mando pelo Direct. Tamo junto e let's go!
>
> **NICHO:** Fitness · **PALAVRA-GATILHO:** TREINO · **GANCHO ALTERNATIVO (Demissão):** "Pode cancelar a academia, porque esse treino de 15 minutos em casa entrega mais."

---

*Framework RG-1 (versão universal) construído por engenharia reversa de 55 Reels de alto desempenho de @rafa.grandi (>40 mil views cada). Aplicável a qualquer nicho. v1, 16/07/2026.*
