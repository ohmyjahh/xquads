---
name: roteiro-viral
description: >-
  Cria roteiros de Reels virais sobre Inteligência Artificial no padrão @rafa.grandi (framework RG-1).
  Use quando o usuário quer gerar um roteiro de Reel/short passando apenas um TEMA (ex: "nova skill do
  Cloud que edita vídeo") ou anexando PRINTS de uma novidade/ferramenta. Gera a narração pronta seguindo
  hook + passo a passo + prova + CTA "comenta que mando no Direct". Baseado na engenharia reversa de 55
  Reels de IA com +40 mil views cada.
---

# Roteiro Viral (Padrão RG-1)

Gera a **narração falada** de um Reel viral sobre IA a partir de um tema ou de prints, replicando o
padrão de 55 Reels de @rafa.grandi (todos >40 mil views, pico de 1,4 milhão).

## Quando usar
- Usuário diz: "cria um roteiro sobre X", "roteiro viral de X", "faz um Reel sobre essa ferramenta".
- Usuário anexa prints de uma novidade/ferramenta de IA e pede um roteiro.
- Usuário quer 2–3 variações de hook para o mesmo tema.

## Entrada esperada
- **Tema** (texto curto): ex. "Cloud agora conecta no Notion", "3 prompts pra estudar mais rápido".
- **OU prints**: analise as imagens (nome da ferramenta, novidade, telas de passo a passo) e use como base factual.
- Se o tema vier vago, faça no máximo 1 pergunta de esclarecimento; caso contrário, gere direto.

## Processo (siga sempre)

1. **Escolha o ângulo do HOOK** — o mais forte entre os 9 tipos (priorize os que mais viralizam):
   - **Demissão/Substituição**: "Pode demitir o teu {profissional}, porque {ferramenta} vai fazer isso por você."
   - **Notícia-bomba**: "O Cloud acabou de {lançar/destruir/resolver} {coisa grande}."
   - **Valor chocante**: "{resultado em R$/seguidores/tempo} usando só {ferramenta}."
   - **Pergunta-curiosidade**: "O que acontece quando você pede pro {IA} {tarefa absurda}?"
   - **Lista numerada**: "Esses são os {N} {prompts/skills/repositórios} que {promessa}."
   - **Prova/resultado**: "Eu criei um skill que me fez {resultado} e vou te ensinar como."
   - **Contrário/polêmico**: afirmação que contraria o senso comum sobre a IA.
   - **Tutorial direto**: "Eu vou te ensinar como {benefício} em menos de 1 minuto."
   - **Promessa de benefício**: "É assim que você consegue {benefício impossível antes}."

2. **Escreva os 6 blocos NA ORDEM**, como texto corrido de narração (sem títulos, sem marcação de cena):
   1. **HOOK** — 1 frase de choque (~8–20 palavras).
   2. **PROMESSA + PONTE** — reafirma o benefício + razão-de-crer (é novo / de graça / uma autoridade fez) + "eu vou te ensinar" / "em menos de 1 minuto".
   3. **PASSO A PASSO** — 4 a 8 micro-passos com conectores: *"Primeiro… Depois… Agora vem o segredo (pulo do gato)… Por último…"*. Ações curtas e imperativas. Inclua UM "segredo" no meio.
   4. **PROVA/PAYOFF** — "olha o resultado / olha o nível / em poucos minutos ele me entregou {resultado concreto}".
   5. **CTA** — "Se você quer que eu te mande **[ENTREGÁVEL específico]**, comenta aqui embaixo **[PALAVRA-GATILHO de 1 palavra ligada ao tema]** que eu te mando pelo Direct."
   6. **ASSINATURA** — termine com **"Tamo junto e let's go!"** (ou "Estamos juntos e let's go!").

3. **Ao final**, entregue em linhas separadas:
   - `PALAVRA-GATILHO: [x]`
   - `GANCHO ALTERNATIVO: [reescreva o hook em outro dos 9 ângulos]`
   - `CONTAGEM: [nº de palavras] palavras / [nº] caracteres`

## Regras obrigatórias (não quebrar)
- **Tamanho**: 170–240 palavras (900–1.400 caracteres). Fala de 45–90 segundos. Se passar, corte.
- **Voz**: 2ª pessoa, oral e informal (mistura "tu/você", "teu/seu"). Frases curtas e imperativas. Nada corporativo, nada de emoji no roteiro.
- **Credibilidade**: use pelo menos 1 número concreto ("mais de 120 agentes", "10x", "100 mil likes") e, quando fizer sentido, 1 nome de autoridade (Anthropic, Google, Microsoft, Adobe, Zuckerberg, o criador da ferramenta).
- **Não invente fatos verificáveis falsos**. Se não souber o dado exato, use faixa plausível ("mais de", "quase", "já passa de").
- **Gatilhos**: encaixe urgência/facilidade/gratuidade quando couber ("acabou de lançar", "totalmente gratuito", "é muito fácil").
- **CTA sempre** com ENTREGÁVEL + PALAVRA-GATILHO. Varie a palavra-gatilho a cada roteiro (não repetir sempre "Cloud").
- **Nomenclatura**: quando o roteiro for falado, "Cloud" = como o dono do perfil se refere ao Claude. Mantenha "Cloud" no texto falado por fidelidade de voz, salvo se o usuário pedir "Claude".

## Padrão de saída
Entregue primeiro o **roteiro limpo** (pronto pra gravar/decorar), depois o bloco de metadados
(PALAVRA-GATILHO / GANCHO ALTERNATIVO / CONTAGEM). Se o usuário pedir variações, gere 2–3 hooks
diferentes para o mesmo corpo.

## Referência completa
O framework detalhado (diagnóstico dos 55 Reels, tabelas de frequência, checklist de viralização e
exemplos) está em `reference.md` nesta mesma pasta. Consulte-o se precisar aprofundar padrões,
mas para gerar um roteiro as regras acima já bastam.

## Checklist rápido antes de entregar
- [ ] Hook cabe em 3s e provoca choque/curiosidade?
- [ ] Tem número concreto e/ou autoridade nos primeiros 8s?
- [ ] Passo a passo com ≤8 micro-passos e 1 "segredo"?
- [ ] Tem momento "olha o resultado"?
- [ ] CTA pede pra comentar 1 palavra-gatilho ligada ao tema?
- [ ] Fechou com "Tamo junto e let's go!"?
- [ ] 170–240 palavras / 900–1.400 caracteres?
