# Como instalar a skill "roteiro-viral" no Claude Code

Esta skill faz o Claude Code gerar roteiros de Reels virais sobre IA no padrão
@rafa.grandi (framework RG-1), a partir de um tema ou de prints.

## Instalação (1 minuto)

1. Descompacte este .zip. Você vai ter uma pasta `roteiro-viral` com os arquivos
   `SKILL.md` e `reference.md`.

2. Mova a pasta `roteiro-viral` inteira para o diretório de skills do Claude Code:

   - **Mac / Linux:** `~/.claude/skills/roteiro-viral/`
   - **Windows:** `C:\Users\SEU_USUARIO\.claude\skills\roteiro-viral\`

   No fim, o caminho deve ficar assim:
   `~/.claude/skills/roteiro-viral/SKILL.md`

3. Abra (ou reinicie) o Claude Code. A skill é detectada automaticamente.

## Como usar

Peça um roteiro passando só o tema:

> cria um roteiro viral sobre a nova skill do Claude que edita vídeo

Ou anexe prints de uma ferramenta/novidade e peça o roteiro. O Claude devolve a
narração pronta pra gravar, no padrão hook + passo a passo + prova + CTA, mais
uma palavra-gatilho e um gancho alternativo.

## O que tem dentro

- `SKILL.md` — as regras que o Claude segue pra gerar o roteiro.
- `reference.md` — o framework completo: diagnóstico dos 55 Reels, tabelas de
  frequência, os 9 tipos de hook, checklist de viralização e exemplos.

Feito por @rafa.grandi.
