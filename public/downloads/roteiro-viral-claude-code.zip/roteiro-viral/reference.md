# FRAMEWORK DE ROTEIROS VIRAIS — Padrão @rafa.grandi (Reels de IA)

> Engenharia reversa de **55 Reels sobre IA acima de 40 mil views** (soma > 15 milhões de views, pico de 1,4 milhão). Este documento tem 4 partes: **(1) Diagnóstico** dos padrões, **(2) O Framework** acionável, **(3) O Gerador** (prompt pronto pra colar tema/prints e sair roteiro) e **(4) Exemplos** gerados do zero.

---

# PARTE 1 — DIAGNÓSTICO (o que os dados provam)

## 1.1 Números-âncora (respeite estes limites)
| Métrica | Valor | Regra prática |
|---|---|---|
| Caracteres | média **1.154** / mediana **1.129** (faixa 600–2.183) | Mire **900–1.400 caracteres** |
| Palavras | média **206** / mediana **202** | Mire **170–240 palavras** |
| Duração falada | média **~82s** (1,4 min) | Reel de **45s–90s** |
| Estrutura | 6 blocos fixos (abaixo) | Nunca pule o Hook nem o CTA |

## 1.2 Frequência de fórmulas (nº de ocorrências nos 55)
- **"te mando pelo Direct"** → 83x (é o motor do engajamento)
- **"let's go!"** (fechamento) → 52x
- **"comenta aqui embaixo [palavra]"** → 42x
- **"tamo/estamos/temos junto"** → 39x
- **"a partir de agora/hoje"** → 24x
- **"acabou de [lançar/ver/resolver]"** → 20x
- **"eu vou te ensinar"** → 16x
- **"me segue aqui embaixo"** → 14x
- **"gratuito/grátis"** → 14x
- **"em menos de X segundos/1 minuto"** → 8x
- **"pode demitir o teu…"** → 6x

## 1.3 Os 9 tipos de HOOK (primeiros 3 segundos)
Todo Reel abre com UM destes ângulos. Ordenados por presença e potência:

1. **DEMISSÃO/SUBSTITUIÇÃO** — "Pode demitir o teu social media/time de marketing, porque…"
   *(Reels 1, 3, 5, 7, 56, 58)*
2. **NOTÍCIA-BOMBA / novidade** — "O Cloud acabou de [lançar/destruir/resolver]…", "A partir de hoje o Cloud se conecta em…"
   *(5, 12, 24, 37, 41, 43, 48, 59, 61)*
3. **TUTORIAL DIRETO** — "Eu vou te ensinar como…", "Como colocar o Cloud pra…"
   *(4, 15, 17, 20, 23, 32)*
4. **PERGUNTA/CURIOSIDADE** — "O que acontece quando você pede pro Cloud…?", "Tu sabia que o Cloud consegue…?"
   *(9, 29, 34)*
5. **LISTA NUMERADA** — "Esses são os 5 prompts secretos…", "10 skills gratuitas…", "3 coisas que você precisa fazer…"
   *(2, 11, 39, 52)*
6. **RESULTADO / PROVA SOCIAL** — "Eu criei um skill que me fez ganhar 100 mil seguidores em 90 dias…", "Esse cara criou uma startup multimilionária sozinho no quarto…"
   *(10, 44)*
7. **PROMESSA DE BENEFÍCIO** — "É assim que você consegue leads infinitos…", "Dessa forma tu vai conseguir…"
   *(8, 42, 47)*
8. **CONTRÁRIO/POLÊMICO** — "O Cloud é uma das IAs mais mentirosas que você conhece", "O Cloud concorda 48% a mais contigo do que um humano"
   *(19, 57)*
9. **VALOR CHOCANTE** — "…criar um Brand Book que valeria mais de 30 mil reais", "aplicativo milionário em 60 segundos"
   *(17, 42)*

## 1.4 Estrutura universal (6 BLOCOS)
```
[1] HOOK          (0–3s)   → 1 frase de choque. Um dos 9 tipos acima.
[2] PROMESSA+PONTE (3–8s)  → o que vai ensinar + porque agora (autoridade/novidade) + "eu vou te ensinar"
[3] PASSO A PASSO (8–55s)  → "Primeiro… depois… agora… por último". Instrução prática, curta, imperativa.
[4] PROVA/PAYOFF  (~5s)    → "e esse é o resultado", "olha o nível", "em poucos minutos ele me entregou…"
[5] CTA           (~8s)    → "Se você quer [ENTREGÁVEL], comenta [PALAVRA] que eu te mando pelo Direct"
[6] ASSINATURA    (~2s)    → "Tamo junto e let's go!"
```

## 1.5 Regras de estilo de escrita (voz da marca)
- **2ª pessoa, oral e informal** — mistura "tu/você", "teu/seu". Fala como amigo, não como professor.
- **Frases curtas e imperativas** no passo a passo: "Você vai entrar nesse site.", "Copia esse link.", "Cola no terminal.", "Clica em download."
- **Conectores de fluxo** obrigatórios: *Primeiro… / Depois… / Agora vem o segredo (ou o pulo do gato)… / Por último… / E o melhor…*
- **Números concretos e específicos** = credibilidade: "120 agentes", "130 cérebros", "30 mil reais", "10x", "100 mil likes no GitHub", "8 milhões de downloads".
- **Nomes de autoridade** ancoram a novidade: Anthropic, Microsoft, Google, Adobe, Zuckerberg, Andrej Karpathy, "o fundador/criador do…".
- **Urgência + escassez + gratuidade**: "acabou de lançar", "menos de 30 segundos", "totalmente gratuito", "só pra quem solicitar acesso".
- **Facilidade**: "é muito fácil e simples", "em menos de 1 minuto".
- **Demonstração em tempo real**: "olha isso", "olha o nível", "esse é o resultado que ele me entregou".

## 1.6 Anatomia do CTA (o motor do algoritmo)
**Fórmula-padrão (usada em ~42 dos 55):**
> "[E] se você quer que eu te mande **[ENTREGÁVEL ESPECÍFICO]**, comenta aqui embaixo **[PALAVRA-GATILHO]** que eu te mando pelo Direct. **Tamo junto e let's go!**"

- **ENTREGÁVEL** = a recompensa concreta: o prompt, o link da ferramenta, o pacote de agentes, o artigo/passo a passo, a skill, a aula.
- **PALAVRA-GATILHO** = 1 palavra curta ligada ao tema, que a pessoa comenta pra receber no Direct. Exemplos reais: `Cloud`, `Insta`, `PDF`, `meta`, `app`, `loop`, `viral`, `humano`, `finanças`, `Google`, `MCP`, `local`, `planilha`, `carrocel`, `GitHub`, `Manus`, `Xquads`.
- **CTA alternativo** (quando não há entregável de Direct): "Se você quer mais conteúdo sobre inteligência artificial, já me segue aqui embaixo. Let's go!"

---

# PARTE 2 — O FRAMEWORK (a fórmula para escrever)

## FÓRMULA VIRAL RG-1 (preencha os blocos)

**BLOCO 1 — HOOK** *(1 frase, ~8–20 palavras)*
Escolha 1 dos 9 tipos. Priorize DEMISSÃO, NOTÍCIA-BOMBA ou VALOR CHOCANTE (os que mais deram >300 mil).
> Templates:
> - "Pode demitir o teu {profissional/time}, porque {ferramenta} vai {fazer tudo isso} por você."
> - "O {IA/empresa} acabou de {lançar/destruir/resolver} {coisa grande}."
> - "A partir de agora você consegue {benefício impossível antes} usando o {ferramenta}."
> - "O que acontece quando você pede pro {IA} {tarefa absurda}? Eu tentei e {resultado}."
> - "Esses são os {N} {prompts/skills/repositórios} {secretos/gratuitos} que {promessa}."
> - "{Valor chocante em R$/seguidores/tempo} usando só {ferramenta}. E eu vou te ensinar como."

**BLOCO 2 — PROMESSA + PONTE** *(1–2 frases)*
Reafirma o benefício, adiciona a razão-de-crer (é novo / é de graça / uma autoridade fez) e promete o passo a passo.
> "…e eu vou te ensinar a fazer isso agora, em menos de 1 minuto." / "É muito fácil e eu vou te mostrar."

**BLOCO 3 — PASSO A PASSO** *(o corpo, 4–8 micro-passos)*
Sequência prática com os conectores. Cada passo = 1 ação curta e imperativa. Insira **1 "segredo/pulo do gato"** no meio (o passo que ninguém conhece).
> "Primeiro, você vai {ação}. Depois, {ação}. **Agora vem o segredo:** {ação diferenciada}. Por último, {ação}."

**BLOCO 4 — PROVA / PAYOFF** *(1–2 frases)*
Mostra o resultado pronto e impressiona.
> "Só com esse prompt, esse é o resultado que ele me entregou. Olha o nível." / "Em poucos minutos ele me entregou {resultado concreto}."

**BLOCO 5 — CTA** *(1–2 frases)*
Use a fórmula do item 1.6. Sempre com ENTREGÁVEL + PALAVRA-GATILHO.

**BLOCO 6 — ASSINATURA**
> "Tamo junto e let's go!" *(ou "Estamos juntos e let's go!")*

## Checklist de viralização (antes de gravar)
- [ ] O Hook cabe em 3 segundos e provoca choque/curiosidade?
- [ ] Tem número concreto ou nome de autoridade nos primeiros 8s?
- [ ] O passo a passo tem no máximo ~8 micro-passos e um "segredo"?
- [ ] Tem um momento "olha o resultado" (payoff visual)?
- [ ] O CTA pede pra comentar UMA palavra-gatilho ligada ao tema?
- [ ] Fechou com "Tamo junto e let's go!"?
- [ ] Total entre 900–1.400 caracteres (~45–90s)?
- [ ] Linguagem oral, frases curtas, "tu/você" informal?

---

# PARTE 3 — O GERADOR (cole isto numa IA + seu tema)

> Copie o bloco abaixo inteiro. Substitua `{{TEMA}}` pelo assunto (ou descreva os prints que vai anexar). A IA devolve o roteiro pronto no padrão.

```
Você é um roteirista de Reels virais especializado em Inteligência Artificial, treinado no
estilo do perfil @rafa.grandi. Sua tarefa é escrever UM roteiro de Reel (só a narração/fala,
sem marcações de cena) sobre o tema abaixo, seguindo EXATAMENTE o framework RG-1.

TEMA / PRINTS: {{TEMA}}

REGRAS OBRIGATÓRIAS:
1. Tamanho: 170–240 palavras (900–1.400 caracteres). Fala de 45–90 segundos.
2. Voz: 2ª pessoa, oral, informal (mistura "tu/você"), frases curtas e imperativas. Nada corporativo.
3. Siga os 6 blocos NA ORDEM, sem títulos, como texto corrido de narração:
   - HOOK (1 frase de choque — escolha o ângulo mais forte entre: Demissão/Substituição,
     Notícia-bomba, Valor chocante, Pergunta-curiosidade, Lista numerada, Prova/resultado,
     Contrário/polêmico).
   - PROMESSA + PONTE: reafirme o benefício + razão-de-crer (é novo / de graça / autoridade fez)
     + "eu vou te ensinar" / "em menos de 1 minuto".
   - PASSO A PASSO: 4 a 8 micro-passos com os conectores "Primeiro… Depois… Agora vem o segredo…
     Por último…". Inclua UM "pulo do gato" no meio.
   - PROVA/PAYOFF: "olha o resultado / olha o nível / em poucos minutos ele me entregou…".
   - CTA: "Se você quer que eu te mande [ENTREGÁVEL específico ligado ao tema], comenta aqui
     embaixo [PALAVRA-GATILHO de 1 palavra ligada ao tema] que eu te mando pelo Direct."
   - ASSINATURA: termine com "Tamo junto e let's go!".
4. Use pelo menos 1 número concreto e, se fizer sentido, 1 nome de autoridade (Anthropic,
   Google, Microsoft, Adobe, o criador da ferramenta etc.). Não invente dados falsos verificáveis;
   se não souber o número exato, use faixas plausíveis ("mais de", "quase").
5. Gatilhos de urgência/facilidade/gratuidade quando couber ("acabou de lançar", "totalmente
   gratuito", "é muito fácil").
6. Entregue TAMBÉM, ao final, em linha separada:
   - "PALAVRA-GATILHO: [x]"
   - "GANCHO ALTERNATIVO: [reescreva o hook em outro dos 9 ângulos]"

Escreva o roteiro agora.
```

### Como usar no dia a dia
1. **Só tema:** troque `{{TEMA}}` por ex. *"nova skill do Cloud que edita vídeo"* → sai o roteiro.
2. **Com prints:** anexe os prints na IA e ponha em `{{TEMA}}`: *"baseie-se nos prints anexados desta ferramenta/novidade"*.
3. Gere 2–3 versões, escolha o hook mais forte (o gerador já te dá um alternativo).
4. Ajuste a PALAVRA-GATILHO pra não repetir sempre a mesma.

---

# PARTE 4 — EXEMPLOS gerados do zero (prova de que funciona)

### Exemplo A — Tema: "Cloud agora edita vídeos automaticamente"
> O Cloud acabou de acabar com os editores de vídeo. A partir de agora você sobe um vídeo bruto e ele te entrega o corte pronto, legendado e no formato de Reels — e eu vou te ensinar a fazer isso em menos de 1 minuto. Primeiro, você vai entrar nesse site e criar sua conta gratuita. Depois, dentro do Cloud, clica em personalizar e conectores. Agora vem o segredo: você vai adicionar esse conector personalizado que quase ninguém conhece e colar o link. Por último, é só jogar o vídeo bruto no chat e pedir: me entregue 5 cortes virais legendados no formato 9:16. E olha o nível — em poucos minutos ele me entregou os cortes prontos pra postar, com legenda e tudo. Um editor trabalhando 24 horas por dia pra você, de graça. Se você quer que eu te mande o link dessa ferramenta com o passo a passo, comenta aqui embaixo VÍDEO que eu te mando pelo Direct. Tamo junto e let's go!
>
> **PALAVRA-GATILHO:** VÍDEO · **GANCHO ALTERNATIVO (Demissão):** "Pode demitir o teu editor de vídeo, porque o Cloud vai fazer todos os teus cortes por você."

### Exemplo B — Tema: "3 configurações que ninguém ativa no Cloud"
> Tem 3 configurações escondidas no Cloud que 95% das pessoas nunca ativaram — e elas mudam completamente a qualidade das tuas respostas. A primeira: entra em configurações, capacidades, e liga a memória. Assim ele lembra de todas as tuas conversas e entende quem é você. A segunda: vai em conectores e conecta o Google Drive e o Gmail, pra ele organizar tudo pra você. Agora vem o pulo do gato: na terceira, você cola um link de curso oficial da Anthropic no chat e escreve — com tudo que você sabe sobre mim, me recomende as melhores skills pro meu perfil. E pronto, ele te entrega um setup personalizado que a maioria leva meses pra descobrir. Fiz isso e a diferença nas respostas foi absurda. Se você quer que eu te mande o passo a passo completo com os prompts, comenta aqui embaixo SETUP que eu te mando pelo Direct. Tamo junto e let's go!
>
> **PALAVRA-GATILHO:** SETUP · **GANCHO ALTERNATIVO (Lista):** "Essas são as 3 configurações secretas do Cloud que vão te colocar na frente de 95% dos usuários."

---

*Framework construído por engenharia reversa de 55 Reels de IA de @rafa.grandi (>40 mil views cada). Padrão RG-1 — v1, 16/07/2026.*
